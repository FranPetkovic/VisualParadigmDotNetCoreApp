﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FranRGIS.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Administrators",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ime = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Priimek = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Administrators", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OdkupElektronikes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VrstaNaprave = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StanjeNaprave = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cena = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OdkupElektronikes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PickUpServiss",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Termin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Lokacija = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PickUpServiss", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RecycleLokacijas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naslov = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OdpiralniCas = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RecycleLokacijas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Oglasis",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naziv = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Opis = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Slike = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cena = table.Column<double>(type: "float", nullable: false),
                    OdkupElektronikeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Oglasis", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Oglasis_OdkupElektronikes_OdkupElektronikeId",
                        column: x => x.OdkupElektronikeId,
                        principalTable: "OdkupElektronikes",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Uporabniks",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UporabniskoIme = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Ime = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Priimek = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Geslo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Lokacija = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PickUpServisId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Uporabniks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Uporabniks_PickUpServiss_PickUpServisId",
                        column: x => x.PickUpServisId,
                        principalTable: "PickUpServiss",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Zemljevids",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Lokacije = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TrenutnaLokacija = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RecycleLokacijaId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Zemljevids", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Zemljevids_RecycleLokacijas_RecycleLokacijaId",
                        column: x => x.RecycleLokacijaId,
                        principalTable: "RecycleLokacijas",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Registracijas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UporabniskoIme = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Ime = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Priimek = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Geslo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UporabnikId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Registracijas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Registracijas_Uporabniks_UporabnikId",
                        column: x => x.UporabnikId,
                        principalTable: "Uporabniks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Oglasis_OdkupElektronikeId",
                table: "Oglasis",
                column: "OdkupElektronikeId");

            migrationBuilder.CreateIndex(
                name: "IX_Registracijas_UporabnikId",
                table: "Registracijas",
                column: "UporabnikId");

            migrationBuilder.CreateIndex(
                name: "IX_Uporabniks_PickUpServisId",
                table: "Uporabniks",
                column: "PickUpServisId");

            migrationBuilder.CreateIndex(
                name: "IX_Zemljevids_RecycleLokacijaId",
                table: "Zemljevids",
                column: "RecycleLokacijaId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Administrators");

            migrationBuilder.DropTable(
                name: "Oglasis");

            migrationBuilder.DropTable(
                name: "Registracijas");

            migrationBuilder.DropTable(
                name: "Zemljevids");

            migrationBuilder.DropTable(
                name: "OdkupElektronikes");

            migrationBuilder.DropTable(
                name: "Uporabniks");

            migrationBuilder.DropTable(
                name: "RecycleLokacijas");

            migrationBuilder.DropTable(
                name: "PickUpServiss");
        }
    }
}

using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace FranRGIS.Models
{
    public class FranRGISDbContext : DbContext
    {

        public DbSet<Administrator> Administrators { get; set; }
        public DbSet<OdkupElektronike> OdkupElektronikes { get; set; }
        public DbSet<Oglasi> Oglasis { get; set; }
        public DbSet<PickUpServis> PickUpServiss { get; set; }
        public DbSet<RecycleLokacija> RecycleLokacijas { get; set; }
        public DbSet<Registracija> Registracijas { get; set; }
        public DbSet<Uporabnik> Uporabniks { get; set; }
        public DbSet<Zemljevid> Zemljevids { get; set; }

        public FranRGISDbContext(DbContextOptions<FranRGISDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<OdkupElektronike>()
                .HasKey(o => o.Id); 

            modelBuilder.Entity<PickUpServis>()
                .HasKey(o => o.Id);

            modelBuilder.Entity<Registracija>()
                .HasKey(o => o.Id);

            modelBuilder.Entity<Zemljevid>()
                .HasKey(o => o.Id);

            modelBuilder.Entity<Oglasi>()
                .HasKey(o => o.Id);

            modelBuilder.Entity<Uporabnik>()
                .HasKey(o => o.Id);

            modelBuilder.Entity<Administrator>()
                .HasKey(o => o.Id);

            modelBuilder.Entity<RecycleLokacija>()
                .HasKey(o => o.Id);

            modelBuilder.Entity<Registracija>()
                .HasKey(o => o.Id);
        }

    }
}

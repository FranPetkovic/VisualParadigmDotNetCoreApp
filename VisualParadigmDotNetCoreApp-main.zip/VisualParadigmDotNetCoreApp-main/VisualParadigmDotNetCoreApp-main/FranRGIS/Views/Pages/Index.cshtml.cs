﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace YourAppNamespace.Pages
{
    public class IndexModel : PageModel
    {
        public string WelcomeMessage { get; set; }

        public void OnGet()
        {
            WelcomeMessage = "Welcome to the ASP.NET Core WebApp!";
        }
    }
}